[CmdletBinding()]
param(
    [string]$DatabaseUrl = "postgres://logmaster:logmaster@localhost:5432/logmaster?sslmode=disable",
    [string]$FeishuAppId = "cli_aac4efb073789bd0",
    [string]$FEISHU_APP_SECRET="n2hyf5r7O1jo89j8srZm0f8OoHYMau2j"
    [string]$FeishuRedirectUri = "http://localhost:8080/api/auth/callback",
    [switch]$SkipInstall
)

$ErrorActionPreference = "Stop"

$backendDir = $PSScriptRoot
$serverDir = Split-Path -Parent $backendDir
$frontendDir = Join-Path $serverDir "frontend"

if (-not (Test-Path -LiteralPath (Join-Path $frontendDir "package.json"))) {
    throw "Frontend directory not found: $frontendDir"
}

if (-not (Test-Path -LiteralPath (Join-Path $backendDir "go.mod"))) {
    throw "Backend directory not found: $backendDir"
}

if ([string]::IsNullOrWhiteSpace($env:FEISHU_APP_SECRET)) {
    $secureSecret = Read-Host "Enter FEISHU_APP_SECRET" -AsSecureString
    $secretPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureSecret)
    try {
        $env:FEISHU_APP_SECRET = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secretPointer)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secretPointer)
    }
}

if ([string]::IsNullOrWhiteSpace($env:FEISHU_APP_SECRET)) {
    throw "FEISHU_APP_SECRET is required."
}

$env:VITE_API_BASE_URL = "/api"
$env:VITE_FEISHU_LOGIN_URL = "/api/auth/feishu-login"

Push-Location $frontendDir
try {
    if (-not $SkipInstall) {
        npm.cmd install
        if ($LASTEXITCODE -ne 0) {
            throw "npm install failed with exit code $LASTEXITCODE"
        }
    }

    npm.cmd run build
    if ($LASTEXITCODE -ne 0) {
        throw "frontend build failed with exit code $LASTEXITCODE"
    }
}
finally {
    Pop-Location
}

$env:DATABASE_URL = $DatabaseUrl
$env:FEISHU_APP_ID = $FeishuAppId
$env:FEISHU_REDIRECT_URI = $FeishuRedirectUri
$env:FRONTEND_DIST_DIR = "..\frontend\dist"

$connection = Test-NetConnection open.feishu.cn -Port 443 -WarningAction SilentlyContinue
if (-not $connection.TcpTestSucceeded) {
    throw "Cannot connect to open.feishu.cn:443"
}

Push-Location $backendDir
try {
    go run .
}
finally {
    Pop-Location
}
